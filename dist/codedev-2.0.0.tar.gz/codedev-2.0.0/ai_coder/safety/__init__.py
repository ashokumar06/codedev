"""
Safety package for secure command execution
"""
