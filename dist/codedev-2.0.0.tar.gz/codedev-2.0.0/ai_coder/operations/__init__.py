"""
Operations package for file and project management
"""
