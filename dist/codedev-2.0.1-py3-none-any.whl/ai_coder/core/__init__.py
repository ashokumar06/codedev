"""
Core functionality package
"""
