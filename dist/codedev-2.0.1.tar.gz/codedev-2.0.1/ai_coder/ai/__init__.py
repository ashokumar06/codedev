"""
AI integration package
"""
